// Offline check of two pinned Pi source files. No provider/client/network calls.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

if (Number(process.versions.node.split('.')[0]) < 24) throw new Error('Use Node.js 24 or later; tested on 24.14.0.');
const manifest = JSON.parse(await readFile(new URL('./source-manifest.json', import.meta.url), 'utf8'));
assert.equal(manifest.commit, '89e12ccd4a5eb587bfa3f4a823baa7cad1549735');
const checks = [];
function check(name, fn) { fn(); checks.push({ name, passed: true }); }
for (const item of manifest.files) {
  const bytes = await readFile(new URL(`./pi-source/${item.file}`, import.meta.url));
  check(`pinned_${item.file}_sha256`, () => assert.equal(createHash('sha256').update(bytes).digest('hex'), item.sha256));
}
const { resolveTranscript } = await import('./pi-source/transcript.ts');
const { getSystemMessageText } = await import('./pi-source/text.ts');

const before = { messages: [
  { role: 'system', content: '', timestamp: 0, sections: { rules: 'Fixed', state: 'Old' } },
  { role: 'user', content: 'Task', timestamp: 1 },
] };
const after = { messages: [...before.messages,
  { role: 'system', content: '', timestamp: 2, sections: { state: 'New' } },
] };
const sameValueUpdate = { messages: [...before.messages,
  { role: 'system', content: '', timestamp: 2, sections: { state: 'Old' } },
] };
const originals = structuredClone({ before, after, sameValueUpdate });
const resolvedBefore = resolveTranscript(before, false);
const resolvedAfter = resolveTranscript(after, false);
const resolvedSame = resolveTranscript(sameValueUpdate, false);
const oldText = getSystemMessageText(resolvedBefore.messages[0]);
const newText = getSystemMessageText(resolvedAfter.messages[0]);
const sameText = getSystemMessageText(resolvedSame.messages[0]);

check('original_event_counts_2_and_3', () => assert.deepEqual([before.messages.length, after.messages.length], [2, 3]));
check('old_event_still_contains_Old', () => assert.equal(after.messages[0].sections.state, 'Old'));
check('resolved_counts_both_2', () => assert.deepEqual([resolvedBefore.messages.length, resolvedAfter.messages.length], [2, 2]));
check('resolved_state_changes', () => assert.deepEqual([resolvedBefore.messages[0].sections.state, resolvedAfter.messages[0].sections.state], ['Old', 'New']));
check('fixed_rule_preserved', () => assert.equal(resolvedAfter.messages[0].sections.rules, 'Fixed'));
check('user_message_preserved', () => assert.deepEqual(resolvedAfter.messages[1], before.messages[1]));
check('old_text_exact', () => assert.equal(oldText, 'Fixed\n\nOld'));
check('new_text_exact', () => assert.equal(newText, 'Fixed\n\nNew'));
check('same_value_patch_keeps_text', () => assert.equal(sameText, oldText));
check('source_objects_unchanged', () => assert.deepEqual({ before, after, sameValueUpdate }, originals));
check('collapsed_head_is_a_new_object', () => assert.notEqual(resolvedAfter.messages[0], after.messages[0]));
check('supported_midconversation_branch_retains_context', () => assert.equal(resolveTranscript(after, true), after));
check('undefined_capability_also_collapses', () => assert.equal(getSystemMessageText(resolveTranscript(after, undefined).messages[0]), newText));

console.log(JSON.stringify({
  node_version: process.versions.node,
  source_commit: manifest.commit,
  scope: 'Executed pinned resolveTranscript/getSystemMessageText locally; no buildParams/provider execution, HTTP request, model or cache measurement.',
  provider_executed: false,
  observed: { event_counts: [2, 3], resolved_counts: [2, 2], old_text: oldText, new_text: newText, same_value_update_text: sameText },
  check_count: checks.length,
  checks,
  status: 'passed',
}, null, 2));
