# Offline Pi text example / 离线 Pi 文本示例

Run with Node.js 24 or later (tested: 24.14.0):

```sh
node system-prompt-after-adapter.mjs
```

The script checks the SHA256 hashes in `source-manifest.json` and then imports
the two unmodified TypeScript source files from Pi commit
`89e12ccd4a5eb587bfa3f4a823baa7cad1549735`. Their MIT license and copyright notice
are preserved in `pi-source/LICENSE`. Node strips type-only syntax; this demo
does not run the project's TypeScript type checker.

The check executes transcript collapsing and system-text rendering only. It does
not call `buildParams`, load a provider SDK, send HTTP requests, or measure cache
hits, token reuse, cost, or latency. The request-field mapping in the article is
a separate source-reading result.

脚本先核对固定源码文件的 SHA256，再直接导入并执行其中的事件折叠和文本渲染函数。
包内保留了上游 MIT 许可；源码未经改写。需要 Node.js 24，本次使用 24.14.0。
这里只擦除 TypeScript 类型语法，不代表通过原项目的类型检查。
不执行 provider／buildParams、不发送请求，也不测量缓存命中或耗时。

Source / 上游来源：
https://github.com/earendil-works/pi/tree/89e12ccd4a5eb587bfa3f4a823baa7cad1549735
